﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace MySQLTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var s = "";
            using (var connection = new MySqlConnection("Database=ipkaDB; Data Source=localhost; User Id=root"))
            {
                var cmd = new MySqlCommand("SELECT * FROM first", connection);
                connection.Open();
                using (var reader = cmd.ExecuteReader())
                {
                    while (reader.Read())
                        s += String.Format("Имя: {0}, возраст: {1}{2}", reader["name"], reader["age"], Environment.NewLine);
                }
            }
            MessageBox.Show(s);            
        }
    }
}
